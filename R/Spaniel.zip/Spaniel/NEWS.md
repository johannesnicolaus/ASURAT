# Spaniel 1.5.0

## New Features

- Import options for 10X Visium data
- Updated vignette for 10X Visium data

## Bug Fixes

- Corrected dependency issue that was causing 
build to fail